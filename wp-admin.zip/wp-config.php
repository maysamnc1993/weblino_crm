<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'weblino_crm' );

/** MySQL database username */
define( 'DB_USER', 'weblino_crm' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Rayanew_0935' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'GSCS*J]T`.upT.3sTsjpi|Cal;XQ;G%4@52Zl<qUh(o:B=<*(57K3I2*vy!/ehZk' );
define( 'SECURE_AUTH_KEY',  'CXoNnOu$- =GVCBS:Ii6csM@hwF/<$|!*/5aQ|J48OIs=2@OY_GR-!vVO6SzY*_4' );
define( 'LOGGED_IN_KEY',    'a_3IYL/u[]QOp;k|;PhJxXY(<_P2RXJ9[/%(o((sVyaZ[9m<]~liNyG7Ctx=PuYX' );
define( 'NONCE_KEY',        '/@Sbd]PXUgEGBo}guzZ;sY{E{F d:hP4S|Nj9Ohlzxj$d(^:9ly8>UJ,+4x|TR@G' );
define( 'AUTH_SALT',        '[beEkwxmqDsyu10=rf^}+>Dg!Zb>-*8e{S[t0b/du*P}c#Ddq,X3lIOJ^|qfkBcN' );
define( 'SECURE_AUTH_SALT', ',+,)OU=]qS6,M[cb[fH6wN6L/zU=$6ic!`Bj~_I+m{mb|0m8+S;8e3z+e,YY F+t' );
define( 'LOGGED_IN_SALT',   'zewpYB&;{^Gf5L][pD2ftH/5Hh|$v&@mCD)UUn@*i~JE%bh`/?X-&%K;$YOBW#N^' );
define( 'NONCE_SALT',       '0)(0*I*MNGQ()tqo#Uxj*UoZa&X4y5jt$PJ%q}Zl#s!S,3~U7Ukc~bR;1dOETtN-' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'cwo_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
